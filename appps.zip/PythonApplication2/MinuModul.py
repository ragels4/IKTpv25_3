def summa(arv1:int, arv2:int) -> int:
    """Tagastab kahe arvu summa.
    :param float arv1: Esimene arv
    :param float arv2: Teine arv
    :return float: Arvude summa
    """
    s=arv1+arv2
    return s
def float_kontroll(sisend:str)->int:
    """Sisestatut tekst teisendab ujuromaarvuks.
    Kui sisestatud täheb, siis palub uuesti sisestada
    :param str sisend: Sisestatud tekst
    :return int: Teisendatud ujukomaarv
    """
    while True:
        try:
            arv=int(sisend)
            return arv
        except ValueError:
            sisend=input("Sisesta arv")

