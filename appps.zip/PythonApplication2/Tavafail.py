from MinuModul import *

a=5
b=float_kontroll(input("Sisesta teine arv: "))
c=summa(a,b)
print(f"Arvude {a} ja {b} summa on {c}.")